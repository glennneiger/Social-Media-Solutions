<h1>
<?php esc_html_e( 'It seems we can&rsquo;t find what you&rsquo;re looking for. Perhaps searching can help.', 'easyweb' ); 
?>
<hr class="vertical-space2">
<?php
get_search_form();
?>
</h1>