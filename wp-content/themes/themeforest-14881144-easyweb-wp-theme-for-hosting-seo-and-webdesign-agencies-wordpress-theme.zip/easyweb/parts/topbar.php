<section class="top-bar">
<div class="container">
<?php
	easyweb_webnus_topbar('left');
	easyweb_webnus_topbar('right');

?>
</div>
</section>