jQuery(document).ready(function(){
	
	/*
	 *
	 * NHP_Options_color function
	 * Adds farbtastic to color elements
	 *
	 */
	 
	 jQuery(document).ready(function($){
    $('.my-color-field').wpColorPicker();
});

	
});