<?php
include_once get_template_directory() . '/inc/nc-options/nc-options.php';
include_once get_template_directory() . '/inc/helpers/woptions.php';
include_once get_template_directory() . '/inc/customizer/customizer.php';
include_once get_template_directory() . '/inc/editor/nc-sc.php';
include_once get_template_directory() . '/inc/widgets/widgets-init.php';

include_once get_template_directory() . '/inc/helpers/breadcrumbs.php';
include_once get_template_directory() . '/inc/helpers/cat-field.php';
include_once get_template_directory() . '/inc/helpers/live-search.php';
include_once get_template_directory() . '/inc/helpers/get-the-image.php';
include_once get_template_directory() . '/inc/helpers/show-ids.php';

include_once get_template_directory() . '/inc/woocommerce/index.php';

include_once get_template_directory() . '/inc/plugins/plugin-activator/init.php';
include_once get_template_directory() . '/inc/plugins/sweet-custom-menu/sweet-custom-menu.php';

include_once get_template_directory() . '/inc/meta-box/meta-box.php';
include_once get_template_directory() . '/inc/meta-box/webnus-meta-box.php';