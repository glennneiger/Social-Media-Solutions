<?php
/*
vc_map( array(
        'name' =>'WFlexSlider',
        'base' => 'flexslider',
        'category' => esc_html__( 'Webnus Shortcodes', 'easyweb' ),
        'show_settings_on_create'=>false,
		'params'=>array(
					array(
							'type' => 'textarea_html',
							'heading' => esc_html__( 'FlexSlider', 'easyweb' ),
							'param_name' => 'content',
							'value' => '[flexitem img="" alt=""][flexitem img="" alt=""]',
							'description' => esc_html__( 'FlexSlider Slides, [flexitem] Acceptable', 'easyweb')
					),
		)
        
    ) );

*/
?>